/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carrerarelevos;

/**
 *
 * @author wilyd
 */
public class Arbitro{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] equipo1 = {"El thread 1", "El thread 2", "El thread 3", "El thread 4"};
		
		
		new Thread(new Corredor(equipo1, "Calle 1")).start();
		
		
               
		
		
		
		
		
		
	}

}
