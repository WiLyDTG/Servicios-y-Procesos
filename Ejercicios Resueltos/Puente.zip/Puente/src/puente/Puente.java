/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package puente;

/**
 *
 * @author wilyd
 */
public class Puente {

   private int pesoAcumulado, personasDentro;
   private static int pesoMaximo=200, personasMaximas=3;
   
   public Puente(){
       pesoAcumulado = 0;
       personasDentro = 0;
       
    
}
   public boolean autorizacionPaso(int peso){
       
       return (pesoAcumulado+ peso)< pesoMaximo && (personasDentro+1)< personasMaximas;
       
       
   }
   
   public void entra(int peso){
       
       personasDentro++;
       pesoAcumulado = pesoAcumulado + peso;
   }
   
   
   public void sale(int peso){
       
       personasDentro--;
       pesoAcumulado = pesoAcumulado + peso;
       if (pesoAcumulado<0) pesoAcumulado=0;
   }
   
   
   
}
   
        
    
    

