/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puente;
import java.util.Random;
/**
 *
 * @author wilyd
 */
public class Persona extends Thread {
    
    private int elPeso;
   
    public Puente elPuente;
    
    public Persona (String nombre, int elPeso, Puente elPuente){
        
        super (nombre);
        this.elPuente= elPuente;
        this.elPeso= elPeso;
        
    }
    @Override
    public void run (){
        
        Random random = new Random();
        int espera = 1000 + random.nextInt(30000);
        System.out.println(Thread.currentThread().getName() + 
				" se esta acercando al puente ... (" + espera/1000 + ")" );
        try{
            Thread.sleep(espera);
            
        } catch(InterruptedException e) {
            e.printStackTrace();
            
        }
        boolean autorizado = true;
		while (!autorizado) {
			synchronized(elPuente) {
				autorizado = elPuente.autorizacionPaso(elPeso);
				if (!autorizado) {
					try {
						System.out.println(Thread.currentThread().getName() + 
								" debe esperar");
						elPuente.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		}
		
		
		
		elPuente.entra(elPeso);
		
		System.out.println(Thread.currentThread().getName() + 
				" cruzando el puente");
		espera = 1000 + random.nextInt(4000);
		try {
			Thread.sleep(espera);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		elPuente.sale(elPeso);
		System.out.println(Thread.currentThread().getName() + 
				" ya ha cruzado el puente");
	}

}