/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puente;

import java.util.Random;
/**
 *
 * @author wilyd
 */
public class puentemain {
    
    public static void main(String [] args){
        
        Puente elPuente = new Puente();
        Persona Personas[] = new Persona[5];
        
        
        Random random = new Random();
        int peso ;
        
        for (int i=0; i<Personas.length;i++){
            
            peso = 40 + random.nextInt(80);
            String nombre = "Persona " + i;
            Personas[i] = new Persona(nombre, peso, elPuente);
            
        }
        for (int i =0; i<Personas.length; i++){
            Personas[i].start();
        }
        
    }
}

