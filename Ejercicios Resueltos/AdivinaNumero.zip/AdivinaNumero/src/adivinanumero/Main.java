/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package adivinanumero;

import java.util.ArrayList;

/**
 *
 * @author wilyd
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Arbitro elarbitro;
        elarbitro = new Arbitro (3);
        
        ArrayList<Jugador> Jugadores;
        Jugadores = new ArrayList<>();
        
        for (int i=1; i<5 ; i++) {
            Jugadores.add(new Jugador( i , "Jugador"+i , elarbitro));
        }
        
        Jugadores.forEach(jugador -> jugador.start());
        
        
    }
    
}