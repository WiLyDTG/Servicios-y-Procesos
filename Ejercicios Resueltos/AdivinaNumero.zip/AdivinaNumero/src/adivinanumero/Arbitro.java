/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adivinanumero;


import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wilyd
 */


public class Arbitro {
    
    private final int numAdivinar;
    private int turno;
    private final int jugadores;
    private boolean terminado;
    
    Arbitro (int numjug) {
        numAdivinar = 1 + (int)(10 * Math.random());
        turno = 1;
        jugadores = numjug;
        terminado = false;
        System.out.println("QUE COMIENCE EL JUEGO. Número a adivinar: " +
                numAdivinar );
        System.out.println("Numero de jugadores: " +
                jugadores );
    }
    
    void cambiaTurno () {
        turno++;
        if (turno>jugadores) turno=1;
    }
    
    void juegoTerminado (int jugada , int jugador) {
        if (jugada == numAdivinar)
        {
            terminado= true;
            System.out.println("\tJUGADOR " + jugador 
                    + " GANA!!! ");   
        }
    }
    
    synchronized void comprobarJugada(int jugador, int jugada) {
        while (turno != jugador) {
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Arbitro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (!isTerminado()) {
            System.out.println("JUGADOR " + jugador 
                    + " propone el numero " + jugada);    
            juegoTerminado(jugada, jugador);
        }
        cambiaTurno();      
        notifyAll();
        
    }

    public int getNumeroAdivinar() {
        return numAdivinar;
    }

    public int getTurno() {
        return turno;
    }

    public boolean isTerminado() {
        return terminado;
    }
    
}