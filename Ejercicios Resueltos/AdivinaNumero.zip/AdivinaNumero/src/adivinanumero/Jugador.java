/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adivinanumero;

/**
 *
 * @author wilyd
 */
public class Jugador extends Thread {
    
    private final int turno;
    private Arbitro arbitro;
    
    Jugador (int elTurno , String elNombre , Arbitro arbitro) {
        turno = elTurno;
        this.arbitro = arbitro;
    }
    
    @Override
    public void run() {
        while (!arbitro.isTerminado()) {
            int numeroAdivinar = 1 + (int)(10 * Math.random());
            arbitro.comprobarJugada(turno, numeroAdivinar);            
        }
    }
    
}
