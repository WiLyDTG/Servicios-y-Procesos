/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

import java.util.ArrayList;

/**
 *
 * @author wilyd
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Saldo misaldo = new Saldo(0);
        
        
        
        ArrayList<Cliente> Clientes;
        Clientes = new ArrayList<>();
        
        for (int i=1; i<5 ; i++) {
            Clientes.add(new Cliente("Cliente "+i , misaldo));
        }
        
        Clientes.forEach(cliente -> cliente.start());
    }
    
}