/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author wilyd
 */
public class Saldo {
    
    private int saldo;
    
    Saldo (int elsaldo) {
        saldo = elsaldo;
    }
    
    synchronized void Ingresar (int cantidad, String nombre) {
        System.out.println(nombre + " ingresa " + cantidad);
        int num = getSaldo() + cantidad;
        setSaldo(num);
        System.out.println("El saldo queda " + getSaldo());
        
    }

    public int getSaldo() {
        int dormir = 1 + (int)(1000 * Math.random());
        try {
            Thread.sleep(dormir);
        } catch (InterruptedException ex) {
            Logger.getLogger(Saldo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return saldo;
    }

    public void setSaldo(int saldo) {
        int dormir = 1 + (int)(1000 * Math.random());
        try {
            Thread.sleep(dormir);
        } catch (InterruptedException ex) {
            Logger.getLogger(Saldo.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.saldo = saldo;
    }
    
}