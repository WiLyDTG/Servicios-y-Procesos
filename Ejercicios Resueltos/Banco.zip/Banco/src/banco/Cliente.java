/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author wilyd
 */
public class Cliente extends Thread {
    
    private String nombre;
    private Saldo saldo;
    
    Cliente (String elnombre , Saldo lacuenta) {
        nombre = elnombre;
        saldo = lacuenta;
    }
    @Override
    public void run () {
        int ingreso = 1 + (int)(250 * Math.random());
        saldo.Ingresar(ingreso , getNombre());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Saldo getSaldo() {
        return saldo;
    }

    public void setSaldo(Saldo saldo) {
        this.saldo = saldo;
    }
    
}